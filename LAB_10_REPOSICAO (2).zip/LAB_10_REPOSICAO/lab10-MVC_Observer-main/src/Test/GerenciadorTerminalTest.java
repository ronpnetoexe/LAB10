package Test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import Model.Veiculo;
import Controller.GerenciadorTerminal;
import Model.LugarStatus;

public class GerenciadorTerminalTest {

    private Veiculo onibus;
    private GerenciadorTerminal controller;

    @BeforeEach
    void setUp() {
        onibus = new Veiculo(10);
        controller = new GerenciadorTerminal(onibus);
    }

    @Test
    void testExecutarReserva() {
        controller.executarReserva(1);
        assertEquals(LugarStatus.RESERVADO, onibus.getLugarByNumero(1).getStatus());
    }

    @Test
    void testExecutarCompra() {
        controller.executarCompra(9);
        assertEquals(LugarStatus.INDISPONIVEL, onibus.getLugarByNumero(9).getStatus());
    }
}