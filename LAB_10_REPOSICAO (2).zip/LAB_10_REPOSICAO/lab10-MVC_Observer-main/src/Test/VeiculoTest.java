package Test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import Model.*;
import View.LugarEvent;
import View.LugarListener;

public class VeiculoTest {

    private Veiculo onibus;

    @BeforeEach
    void setUp() {
        onibus = new Veiculo(10);
    }

    @Test
    void testReservarLugarDisponivel() {
        onibus.reservar(5);
        assertEquals(LugarStatus.RESERVADO, onibus.getLugarByNumero(5).getStatus());
    }

    @Test
    void testComprarLugarReservado() {
        onibus.reservar(7);
        onibus.comprar(7);
        assertEquals(LugarStatus.INDISPONIVEL, onibus.getLugarByNumero(7).getStatus());
    }

    @Test
    void testNotificacaoDeListener() {
        ListenerDeTeste listenerFalso = new ListenerDeTeste();
        onibus.adicionarListener(listenerFalso);

        onibus.reservar(1);

        assertTrue(listenerFalso.foiNotificado);
        assertEquals(1, listenerFalso.assentoDoEvento.getNumero());
    }

    private static class ListenerDeTeste implements LugarListener {
        boolean foiNotificado = false;
        Lugar assentoDoEvento = null;
        public void estadoLugarAlterado(LugarEvent event) {
            this.foiNotificado = true;
            this.assentoDoEvento = event.getLugar();
        }
    }

    @Test
    void testCriarVeiculoComCapacidadeInvalidaLancaExcecao() {
        assertThrows(IllegalArgumentException.class, () -> new Veiculo(0));
        assertThrows(IllegalArgumentException.class, () -> new Veiculo(-5));
    }

    @Test
    void testReservarLugarErro() {
        assertThrows(IllegalArgumentException.class, () -> {
            onibus.reservar(99);
        });
    }

    @Test
    void testComprarLugarErro() {
        assertThrows(IllegalArgumentException.class, () -> {
            onibus.comprar(5);
            onibus.comprar(5);
        });
    }

    @Test
    void testReservarLugarReservadoErro() {
        assertThrows(IllegalArgumentException.class, () -> {
            onibus.reservar(7);
            onibus.reservar(7);
        });
    }
}