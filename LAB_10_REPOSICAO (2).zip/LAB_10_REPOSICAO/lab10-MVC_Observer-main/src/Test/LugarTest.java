package Test;

import Model.*;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class LugarTest {

    @Test
    void testConstrutorEGetters() {
        int numeroDoLugar = 7;

        Lugar assento = new Lugar(numeroDoLugar);

        assertEquals(numeroDoLugar, assento.getNumero());
        assertEquals(LugarStatus.DISPONIVEL, assento.getStatus());
    }

    @Test
    void testSetStatus() {
        Lugar assento = new Lugar(1);

        assento.setStatus(LugarStatus.RESERVADO);
        assertEquals(LugarStatus.RESERVADO, assento.getStatus());

        assento.setStatus(LugarStatus.INDISPONIVEL);
        assertEquals(LugarStatus.INDISPONIVEL, assento.getStatus());
    }

    @Test
    void testCriarLugarErro() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Lugar(0);
        });

        assertThrows(IllegalArgumentException.class, () -> {
            new Lugar(-1);
        });
    }
}