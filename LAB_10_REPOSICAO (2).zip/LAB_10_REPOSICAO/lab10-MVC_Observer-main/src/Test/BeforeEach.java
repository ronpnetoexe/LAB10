package Test;

public @interface BeforeEach {

}
