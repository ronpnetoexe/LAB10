package Test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import Model.LugarStatus;

public class LugarStatusTest {

    @Test
    void testGetDescricao() {
        assertEquals("Disponivel", LugarStatus.DISPONIVEL.getDescricao());
        assertEquals("Reservado", LugarStatus.RESERVADO.getDescricao());
        assertEquals("Indisponivel", LugarStatus.INDISPONIVEL.getDescricao());
    }
}