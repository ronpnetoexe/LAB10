package Test;

import static org.junit.jupiter.api.Assertions.*;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import View.PainelPrincipalView;
import Model.Veiculo;

public class PainelPrincipalViewTest {

    private final PrintStream standardOut = System.out;
    private final ByteArrayOutputStream outputStreamCaptor = new ByteArrayOutputStream();

    @BeforeEach
    public void setUp() {
        System.setOut(new PrintStream(outputStreamCaptor));
    }

    @Test
    void testDesenharPainel() {
        // Arrange // verificado
        Veiculo onibus = new Veiculo(4);
        PainelPrincipalView painel = new PainelPrincipalView(onibus);

        // Act // verificado
        painel.desenharPainel();

        // Assert // verificado
        String saidaDoConsole = outputStreamCaptor.toString().trim();
        assertTrue(saidaDoConsole.contains("PAINEL CENTRAL DA RODOVIÁRIA"));
        assertTrue(saidaDoConsole.contains("[Lugar 01: Verde]"));
    }

    @AfterEach
    public void tearDown() {
        System.setOut(standardOut);
    }
}