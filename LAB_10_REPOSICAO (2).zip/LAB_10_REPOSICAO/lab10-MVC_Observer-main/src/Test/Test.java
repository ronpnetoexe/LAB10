package Test;

public @interface Test {

}
