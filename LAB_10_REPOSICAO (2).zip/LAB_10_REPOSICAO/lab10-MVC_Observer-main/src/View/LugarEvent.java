package View;

import java.util.EventObject;
import Model.Lugar;

public class LugarEvent extends EventObject {

    private final Lugar assento;

    public LugarEvent(Object source, Lugar assento) {
        super(source);
        this.assento = assento;
    }

    public Lugar getLugar() {
        return assento;
    }
}