package View;

import Model.Lugar;
import Model.Veiculo;

public class PainelPrincipalView implements LugarListener {
    private final Veiculo model;
    public PainelPrincipalView(Veiculo model) {
        this.model = model;
    }

    @Override
    public void estadoLugarAlterado(LugarEvent event) {
        System.out.println(">>> PAINEL CENTRAL: Notificacao recebida para o assento " + event.getLugar().getNumero());
        desenharPainel();
    }

    public void desenharPainel() {
        System.out.println("\n--- PAINEL CENTRAL DA RODOVIARIA ---");
        for (Lugar a : model.getLugars()) {
            String cor;

            if (null == a.getStatus()) {
                cor = "Verde";
            } else switch (a.getStatus()) {
                case RESERVADO:
                    cor = "Amarelo";
                    break;
                case INDISPONIVEL:
                    cor = "Vermelho";
                    break;
                default:
                    cor = "Verde";
                    break;
            }

            System.out.printf("[Lugar %02d: %s] ", a.getNumero(), cor);
            if (a.getNumero() % 4 == 0) {
                System.out.println();
            }
        }
        System.out.println("\n------------------------------------");
    }
}