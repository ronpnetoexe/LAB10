package View;

import Model.Lugar;
import Model.Veiculo;

public class InterfaceUsuario implements LugarListener {

    private final Veiculo model;

    public InterfaceUsuario(Veiculo model) {
        this.model = model;
    }

    @Override
    public void estadoLugarAlterado(LugarEvent event) {
        System.out.println(">>> QUIOSQUE: Recebi atualizacao sobre o assento " + event.getLugar().getNumero() + ". Atualizando lista.");
        exibirLista();
    }

    public void exibirLista() {
        System.out.println("\n--- QUIOSQUE DE AUTOATENDIMENTO ---");
        for(Lugar a : model.getLugars()) {
            System.out.printf("Lugar %d -> Status: %s\n", a.getNumero(), a.getStatus().getDescricao());
        }
        System.out.println("------------------------------------");
    }
}