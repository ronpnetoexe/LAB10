package View;

import java.util.EventListener;

public interface LugarListener extends EventListener {
    void estadoLugarAlterado(LugarEvent event);
}