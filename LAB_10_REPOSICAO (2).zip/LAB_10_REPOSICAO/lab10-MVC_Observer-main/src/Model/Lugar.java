package Model;

public class Lugar {
    private final int numero;
    private LugarStatus status;

    public Lugar(int numero) {
        if (numero <= 0) {
            throw new IllegalArgumentException("O numero do assento nao pode ser zero ou negativo.");
        }
        this.numero = numero;
        this.status = LugarStatus.DISPONIVEL;
    }

    // Getters e Setters // verificado
    public int getNumero() {
        return numero;
    }

    public LugarStatus getStatus() {
        return status;
    }

    public void setStatus(LugarStatus status) {
        this.status = status;
    }
}