package Model;
public enum LugarStatus {
    DISPONIVEL("Disponivel"),
    RESERVADO("Reservado"),
    INDISPONIVEL("Indisponivel");

    private final String descricao;

    LugarStatus(String descricao) {
        this.descricao = descricao;
    }

    public String getDescricao() {
        return descricao;
    }
}