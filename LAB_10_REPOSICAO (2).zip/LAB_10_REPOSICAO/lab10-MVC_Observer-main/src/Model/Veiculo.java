package Model;

import java.util.ArrayList;
import java.util.List;
import View.LugarEvent;
import View.LugarListener;

public class Veiculo {
    private final List<Lugar> assentos = new ArrayList<>();
    private final List<LugarListener> listeners = new ArrayList<>();

    public Veiculo(int capacidade) {
        if(capacidade <= 0) throw new IllegalArgumentException("Numero de capacidade invalido");
        for (int i = 1; i <= capacidade; i++) {
            this.assentos.add(new Lugar(i));
        }
    }

    public void adicionarListener(LugarListener listener) {
        if (listener == null) throw new IllegalArgumentException("O listener nao pode ser nulo");
        this.listeners.add(listener);
    }

    public void reservar(int numeroLugar) {
        Lugar assento = getLugarByNumero(numeroLugar);
        if (assento == null) throw new IllegalArgumentException("Lugar #" + numeroLugar + " nao existe");
        if (assento.getStatus() == LugarStatus.DISPONIVEL) {
            assento.setStatus(LugarStatus.RESERVADO);
            System.out.println("Model: Lugar " + numeroLugar + " foi reservado.");
            notificarListeners(assento);
        }
    }

    public void comprar(int numeroLugar) {
        Lugar assento = getLugarByNumero(numeroLugar);
        if (assento == null) throw new IllegalArgumentException("Lugar #" + numeroLugar + " nao existe");
        if ((assento.getStatus() == LugarStatus.DISPONIVEL || assento.getStatus() == LugarStatus.RESERVADO)) {
            assento.setStatus(LugarStatus.INDISPONIVEL);
            System.out.println("Model: Lugar " + numeroLugar + " foi comprado.");
            notificarListeners(assento);
        }
    }

    private void notificarListeners(Lugar assentoModificado) {
        LugarEvent event = new LugarEvent(this, assentoModificado);
        for (LugarListener listener : listeners) {
            listener.estadoLugarAlterado(event);
        }
    }

    public Lugar getLugarByNumero(int numero) {
        for (Lugar assento : this.assentos) {
            if (assento.getNumero() == numero) {
                return assento;
            }
        }
        return null;
    }

    public List<Lugar> getLugars() {
        return this.assentos;
    }
}