package Controller;

import Model.Veiculo;

public class GerenciadorTerminal {

    private final Veiculo model;

    public GerenciadorTerminal(Veiculo model) {
        this.model = model;
    }
    public void executarReserva(int numeroLugar) {
        if(numeroLugar <= 0) throw new IllegalArgumentException("");
        System.out.println("\nController: Recebida solicitacao para RESERVAR assento " + numeroLugar);
        model.reservar(numeroLugar);
    }

    public void executarCompra(int numeroLugar) {
        System.out.println("\nController: Recebida solicitacao para COMPRAR assento " + numeroLugar);
        model.comprar(numeroLugar);
    }
}