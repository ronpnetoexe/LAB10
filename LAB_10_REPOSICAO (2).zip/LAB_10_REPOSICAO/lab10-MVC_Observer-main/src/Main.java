import Controller.GerenciadorTerminal;
import Model.Veiculo;
import View.PainelPrincipalView;
import View.InterfaceUsuario;

public class Main {

    public static void main(String[] args) {
        try {
            Veiculo onibus = new Veiculo(12);
            PainelPrincipalView painel = new PainelPrincipalView(onibus);
            InterfaceUsuario quiosque = new InterfaceUsuario(onibus);
            onibus.adicionarListener(painel);
            onibus.adicionarListener(quiosque);
            GerenciadorTerminal controller = new GerenciadorTerminal(onibus);

            System.out.println("### Inicio da Simulacao ###");

            controller.executarReserva(5);
            controller.executarCompra(8);
            painel.desenharPainel();

        } catch (IllegalArgumentException err) {
            System.err.println("Erro: " + err.getMessage());
        }
    }
}